let fields = ["id","displayName","nickname","phoneNumbers","emails","addresses","organizations","birthday","note","categories","urls"];

var sessionId="";
var currentDevice="";
var events = 0;
var user_editing=false;
var userToEdit=null;
var connected=false;

var app = {
    onDeviceReady: function() {
        addClickEvents();
    }
};

$(document).ready(function() {
    document.addEventListener("deviceready", app.onDeviceReady, false);
});

function addClickEvents() {
    $(".scanBtn").on("click",function () {
        scanQr();
    });
    $(".manualSession").on("click",function () {
        navigator.notification.prompt("Insert the session ID", function (result) {
            sessionId = result.input1;
            currentDevice = device.uuid;
            var info = device.model+", "+device.platform+" "+device.version;
            $.get("http://hcicontactsmanager2017.altervista.org/createSession.php?ID="+sessionId+"&device="+currentDevice+"&info="+info, function(data, status){
                if(data!=1){
                    $("#events_log").css("display","block")
                    $("button").css("display","none")
                    uploadContacts()
                    addEventToLog("Session "+sessionId+" restored");
                    sendEvent("phone","connected");
                    setInterval(function () {
                        checkForEvents();
                    },2000)

                }else{
                    alert("Error, session not found");
                }
            });
        }, "Restore a session",["Ok","Cancel"],"")
    });
    document.addEventListener("backbutton", function(e){
        navigator.notification.confirm(
            "Do you really want to close this app?",
            function(buttonIndex){
                if(buttonIndex == "1"){
                    sendEvent("phone","disconnected")
                    navigator.app.exitApp();
                }else{
                    return;
                };
            },
            "Confirmation",
            "Yes,No"
        );
    });
}

function addEventToLog(event) {
    /*
        Add and shows a new event
     */
    events++;
    var currentdate = new Date();
    var datetime =currentdate.getHours() + ":"
        + currentdate.getMinutes() + ":"
        + currentdate.getSeconds();
    $("#events_log").html($("#events_log").html()+'<div class="event_cont"><p class="event">'
        +datetime+" "+event
        +'</p></div>');
}

function checkForEvents(){
    $.ajax({
        type:     "post",
        data:     {device_session: this.currentDevice+"_"+this.sessionId},
        cache:    false,
        url:      "http://hcicontactsmanager2017.altervista.org/checkForNewEvent.php",
        error: function (request, error) {
            console.log(arguments);
            //alert(" Can't do because: " + error);
        },
        success: function (data) {
            if(data!="null"){
                var jsonEvent = JSON.parse(data);
                //jsonEvent = JSON.parse(jsonEvent.data);
                var jsonData = JSON.parse(jsonEvent.data);
                //addEventToLog("Events check1: "+jsonData.event);
                switch(jsonData.event){
                    case "connection":
                        if(!connected) {
                            addEventToLog("Connected succesfully");
                            sendEvent("phone", "connected");
                            connected = true;
                        }
                        break;
                    case "delete":
                        addEventToLog("Request to delete "+jsonData.event_data);
                        deleteContact(jsonData.event_data);
                        break;
                    case "edit":
                        addEventToLog("Request to edit "+jsonData.event_data.displayName);
                        userToEdit=jsonData.event_data;
                        editContact();
                        break;
                    case "new":
                        console.log(JSON.stringify(jsonData.event_data));
                        addEventToLog("Request to create "+jsonData.event_data.displayName);
                        createContact(jsonData.event_data);
                        break;
                    case "refresh":
                        addEventToLog("Updating contacts..");
                        uploadContacts();
                        break;
                    case "sms":
                        addEventToLog("Sending sms to "+jsonData.event_data.receiver);
                        sendSms(jsonData.event_data);
                        break;
                    case "phone":
                        break;
                    default:
                        addEventToLog("Unknown event: "+jsonData.event);
                        break;
                }
            }

        }
    });
}

function sendSms(data) {
    /*
        Send a sms
     */
   var number = data.receiver.toString();
   var text = data.text;

    //CONFIGURATION
    var options = {
        replaceLineBreaks: false, // true to replace \n by a new line, false by default
        android: {
            intent: ''  // send SMS with the native android SMS messaging
            //intent: '' // send SMS without open any other app
        }
    };

    var success = function () { addEventToLog('Message sent successfully'); };
    var error = function (e) { addEventToLog('Message Failed:' + e); };
    sms.send(number, text, options, success, error);
    console.log(text)

}

function sendEvent(type,data){
    var packet={};
    packet.event=type;
    packet.event_data=data;
    var codex=currentDevice+"_"+this.sessionId;
    $.ajax({
        type:     "post",
        data:     {codex:"phone_"+codex,data: JSON.stringify(packet)},
        cache:    false,
        url:      "http://hcicontactsmanager2017.altervista.org/addNewEvent.php",
        error: function (request, error) {
            console.log(arguments);
            //alert(" Can't do because: " + error);
        },
        success: function (data) {
            console.log("Result adding event check: "+data);
        }
    });
    // NEL SUCCESS?
    /*
    switch(type){
        case "refresh":
            //FAI PARTIRE IL REFRESH
    }
    */
}

function deleteContact(id) {
    /*
        Delete the contatc
     */
    var options = new ContactFindOptions();
    options.filter = id;
    options.multiple = false;
    fields = ["id"];
    navigator.contacts.find(fields, contactfindSuccess, contactfindError, options);

    function contactfindSuccess(contacts) {
            var contact = contacts[0];
            var contactBackup = contacts[0];

            if(contact===undefined){
                return;
            }

            contact.remove(contactRemoveSuccess, contactRemoveError);

            function contactRemoveSuccess(contact) {
                    addEventToLog('Contact deleted');
            }

        function contactRemoveError(message) {
                addEventToLog('Errore nell\'eliminazione del contatto:' + message);
        }
    }

    function contactfindError(message) {
            addEventToLog('Errore nell\'eliminazione del contatto:' + message);
    }

}

function editContact() {
    /*
        Not working (Cordova compatibility problem) -> not used in web application
     */
    user_editing=true;

    var options = new ContactFindOptions();
    options.filter = userToEdit.id+'';
    options.multiple = true;
    fields = ["id"];
    navigator.contacts.find(fields, contactfindSuccess, contactfindError, options);

    function contactfindSuccess(contacts) {
        var contact = contacts[0];
        if(contact===undefined){
            addEventToLog("Error editing contact: user not found");
            return;
        }

        if(userToEdit.nickname!=""){
            if(contact.nickname!=null){
                contact.nickname=userToEdit.nickname;
            }else{
                contact.nickname=userToEdit.nickname;
            }
        }
        if(userToEdit.note!=""){
            if(contact.note!=null){
                contact.note=userToEdit.note;
            }else{
                contact.note=userToEdit.note;
            }
        }
        if(userToEdit.phoneNumbers!=""){
            if(contact.phoneNumbers!=null){
                contact.phoneNumbers[0].value=userToEdit.phoneNumbers.split(",")[0]+'';
            }else{
                var phoneNumbers = [];
                phoneNumbers[0] = new ContactField('home', userToEdit.phoneNumbers.split(",")[0]+'', true);
                contact.phoneNumbers = phoneNumbers;
            }
        }
        if(userToEdit.emails!=""){
            if(contact.emails!=null){
                contact.emails[0].value=userToEdit.emails.split(",")[0]+'';
            }else{
                var emails = [];
                emails[0] = new ContactField('home', userToEdit.emails.split(",")[0]+'', true);
                contact.emails = emails;
            }
        }
        if(userToEdit.urls!=""){
            if(contact.urls!=null){
                contact.urls[0].value=userToEdit.urls.split(",")[0]+'';
            }else{
                var urls = [];
                urls[0] = new ContactField('home', userToEdit.urls.split(",")[0]+'', true);
                contact.urls = urls;
            }
        }
        if(userToEdit.addresses!=""){
            if(contact.addresses!=null){
                contact.addresses[0].formatted=userToEdit.addresses.split(",")[0]+'';
            }else{
                var addresses = [];
                addresses[0] = new ContactAddress (true,'home', userToEdit.addresses.split(",")[0]+'', '','', '','','');
                contact.addresses = addresses;
            }
        }
        if(userToEdit.organizations!=""){
            if(contact.organizations!=null){
                contact.organizations[0].name=userToEdit.organizations.split(",")[0]+'';
            }else{
                var organizations = [];
                organizations[0] = new ContactOrganization (true,'home', userToEdit.organizations.split(",")[0]+'', '','');
                contact.organizations = organizations;
            }
        }

        var c =contact;
        console.log("Editing saving "+JSON.stringify(c));

        try {
            c.save(onSaveSuccess,onSaveError);
        }catch (err){
            addEventToLog("Error in contact editing: "+err)

        }

        function onSaveSuccess(cont) {
            console.log("Save Success\n"+JSON.stringify(cont));
            addEventToLog("Contact edited succesfully!");
        }

        function onSaveError(contactError) {
            alert("Error = " + contactError.code);
        }

    }

    function contactfindError(message) {
        alert('Failed because: ' + message);
    }


}

function createContact(user) {
    /*
        Create a new contact
     */

    var emails = [];
    for(var i=0;i<user.emails.split(",").length;i++){
        emails[i]= new ContactField('Altro', user.emails.split(",")[i], false);
    }

    var phoneNumbers = [];
    for(var i=0;i<user.phoneNumbers.split(",").length;i++){
        phoneNumbers[i]= new ContactField('Altro', user.phoneNumbers.split(",")[i], false);
    }

    var addresses = [];
    for(var i=0;i<1;i++){
        addresses[i]= new ContactAddress();
        addresses[i].pref=false;
        addresses[i].type="home";
        addresses[i].formatted=user.addresses.split(",")[i];
        addresses[i].streetAddress="";
        addresses[i].locality="";
        addresses[i].region="";
        addresses[i].postalCode="";
        addresses[i].country="";
    }

    var organizations = [];
    for(var i=0;i<user.organizations.split(",").length;i++){
        organizations[i]= new ContactOrganization();
        organizations[i].pref=false;
        organizations[i].type="home";
        organizations[i].name=user.organizations.split(",")[i];
        organizations[i].department="";
        organizations[i].title="";
    }

    var urls = [];
    for(var i=0;i<user.urls.split(",").length;i++){
        urls[i]= new ContactField('Altro', user.urls.split(",")[i], false);
    }

    var myContact = navigator.contacts.create({
        "displayName": (user.displayName!="")?user.displayName:null,
        "nickname": (user.nickname!="")?user.nickname:null,
        "emails": emails,
        "phoneNumbers": phoneNumbers,
        "addresses": addresses,
        "organizations": organizations,
        "birthday": (user.birthday===null||user.birthday==="")? 0:(new Date(user.birthday)),
        "note": (user.note!="")? (user.note):null,
        "urls": urls,
    });
    myContact.save(contactSuccess, contactError);

    function contactSuccess() {
            addEventToLog("Contact created successfully");
    }

    function contactError(message) {
            addEventToLog("Errore creazione contatto: " + message);
    }


}

function scanQr() {
    /*
        Start the scanning of the qr code
     */
    cordova.plugins.barcodeScanner.scan(
        function (result) {
            if(!result.cancelled){
                // In this case we only want to process QR Codes
                if(result.format == "QR_CODE"){
                    sessionId = result.text;
                    currentDevice = device.uuid;
                    var info = device.model+", "+device.platform+" "+device.version;

                    $.get("http://hcicontactsmanager2017.altervista.org/createSession.php?ID="+sessionId+"&device="+currentDevice+"&info="+info, function(data, status){
                        if(data==1){
                            $("#events_log").css("display","block")
                            $("button").css("display","none")
                            uploadContacts()
                            addEventToLog("Starting session "+sessionId);
                            setInterval(function () {
                                checkForEvents();
                            },2000)

                        }else{
                            alert("Error, please retry");
                        }
                    });

                }else{
                    alert("Sorry, only qr codes this time ;)");
                }
            }else{
                alert("The user has dismissed the scan");
            }
        },
        function (error) {
            alert("An error ocurred: " + error);
        }
    );
}

function uploadContacts() {
    /*
        Upload the contacts to the server
     */

var contacts = [];

    var options      = new ContactFindOptions();
    options.filter   = "";
    options.multiple = true;

    navigator.contacts.find(fields, function (cs) {
        for(var i=0, len=cs.length; i<len; i++) {
            var obj = {};
            var contact = cs[i];
                obj["id"]=contact.id;

                obj["displayName"]=contact.displayName;
                obj["nickname"]=contact.nickname;
                obj["emails"]=[];
                if(contact.emails!=null){
                    for(var k=0;k<contact.emails.length;k++){
                        obj["emails"].push(contact.emails[k].value);
                    }
                }
                obj["phoneNumbers"]=[];
                if(contact.phoneNumbers!=null){
                    for(var k=0;k<contact.phoneNumbers.length;k++){
                        obj["phoneNumbers"].push(contact.phoneNumbers[k].value);
                    }
                }
                obj["addresses"]=[];
                if(contact.addresses!=null){
                    for(var k=0;k<contact.addresses.length;k++){
                        obj["addresses"].push(contact.addresses[k].formatted);
                    }
                }

                obj["organizations"]=[];
                if(contact.organizations!==null){
                    for(var k=0;k<contact.organizations.length;k++){
                        obj["organizations"].push(contact.organizations[k].name);
                    }
                }
                obj["birthday"]=(contact.birthday===null)?"":contact.birthday;

                obj["note"]=contact.note;

                obj["categories"]=[];
                if(contact.categories!==null){
                    for(var k=0;k<contact.categories.length;k++){
                        obj["categories"].push(contact.categories[k].value);
                    }
                }

                obj["urls"]=[];
                if(contact.urls!==null){
                    for(var k=0;k<contact.urls.length;k++){
                        obj["urls"].push(contact.urls[k].value);
                    }
                }

                if(i===42) {
                    console.log(JSON.stringify(obj));
                }
                contacts.push(obj);

        }

        $.ajax({
            type:     "post",
            data:     {sessionId: sessionId,device:currentDevice,data:JSON.stringify(contacts)},
            cache:    false,
            url:      "http://hcicontactsmanager2017.altervista.org/uploadContacts.php",
            error: function (request, error) {
                console.log(arguments);
                addEventToLog("Errore nel caricamento dei contatti, riprovare");
            },
            success: function (data) {
                console.log("Result session check: "+data);
                sendEvent("phone","upload_contacts_completed");
                addEventToLog("Contacts loaded successfully");
            }
        });

    }, function () {
        console.log(("find error"));
    }, options);

}